import React from 'react'

const ManagerSchemeResolution = () => {
  return (
    <div>ManagerSchemeResolution</div>
  )
}

export default ManagerSchemeResolution