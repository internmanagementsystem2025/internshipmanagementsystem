import React from 'react'

const InternPlaced = () => {
  return (
    <div>InternPlaced</div>
  )
}

export default InternPlaced