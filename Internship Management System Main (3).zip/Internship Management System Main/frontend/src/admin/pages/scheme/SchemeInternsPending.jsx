import React from 'react'

const SchemeInternsPending = () => {
  return (
    <div>SchemeInternsPending</div>
  )
}

export default SchemeInternsPending